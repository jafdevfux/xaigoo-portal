<?php

// SPDX-License-Identifier: MIT
// Xaigoo Pipeline — API config (NÃO commitar com credenciais reais)
// Este arquivo é gitignored via .gitignore

declare(strict_types=1);

// -- Banco de dados (HomeHost - cPanel) -------------------------------------
// Database: xaigoo_links-pipeline  | Host: localhost (na HomeHost PHP e MySQL estão no mesmo servidor)
// IMPORTANTE: Host "localhost" funciona apenas quando a API roda NA HomeHost.
// Para dev local conectar remoto, a HomeHost precisa liberar "MySQL Remoto" e
// informar o host externo (ex: mysql.homehost.com.br ou IP). Se não liberar,
// o frontend local usará fallback mock até o deploy.
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'xaigoo_links-pipeline');
define('DB_USER', 'xaigoo_links-pipeline');
define('DB_PASS', 'hr7V534bqqmHWzSSxS9J');
define('DB_CHARSET', 'utf8mb4');

// -- Aplicação --------------------------------------------------------------
define('APP_ENV', 'development'); // 'production' na HomeHost, 'development' local

// -- CORS -------------------------------------------------------------------
define('CORS_ALLOWED_ORIGINS', 'http://localhost:3000,http://127.0.0.1:3000,https://portal.xaigoo.app,https://www.portal.xaigoo.app,https://api.xaigoo.app,https://www.xaigoo.app,https://xaigoo.app,https://xaigoo-portal.vercel.app');

// -- Auth -------------------------------------------------------------------
// Nome da sessão PHP e regra de domínio permitida (apenas @xaigoo.app exato)
define('AUTH_SESSION_NAME', 'xaigoo_session');
define('AUTH_DOMAIN_RULE', '@xaigoo.app');

// -- Timezone ---------------------------------------------------------------
date_default_timezone_set('America/Sao_Paulo');
