// Xaigoo Extractor - Content Script (Instagram Followers Modal)
// Extrai username e profile_url do modal/dialog de seguidores do Instagram
// Envia para backend via background service worker (ponte obrigatória em MV3)
// NOTA: Em MV3, fetch() no content script roda no origin da PÁGINA (instagram.com).
//       Requisições cross-origin para portal.xaigoo.app DEVEM ir pelo background.

(function () {
  'use strict';

  // ============ ESTADO ============
  let isExtensionActive = true;
  let isAIActive = false;
  let isModalActive = false;
  let isVerifyActive = false; // Toggle de verificação de visibilidade
  let seenUsernames = new Set();
  let sendQueue = [];
  let isProcessingQueue = false;
  let observer = null;
  let scanInterval = null;
  let scrollCheckInterval = null;
  let modalEl = null;
  let modalStatsInterval = null;
  let modalTheme = 'light'; // Tema do modal: 'light' ou 'dark' (controlado pelo usuário)

  // Contador de leads capturados NA SESSÃO DA EXTENSÃO (reseta ao ligar/desligar)
  let sessionCount = 0;
  let sessionLevel1 = 0;
  let sessionLevel2 = 0;

  // ============ LOG ============
  function log(...args) {
    console.log('[Xaigoo Extractor]', ...args);
  }

  // ============ PONTE PARA BACKGROUND ============

  // Envia perfil para salvar no banco via background
  function saveLead(profile) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        {
          type: 'SAVE_LEAD',
          profile: profile,
          ai_enabled: isAIActive,
        },
        (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          if (!response) {
            reject(new Error('Sem resposta do background'));
            return;
          }
          resolve(response);
        }
      );
    });
  }

  // Busca estatísticas via background
  function fetchStats() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'GET_STATS' }, (response) => {
        if (chrome.runtime.lastError) {
          resolve(null);
          return;
        }
        resolve(response);
      });
    });
  }

  function incrementCounter() {
    chrome.runtime.sendMessage({ type: 'INCREMENT_COUNTER' }, () => {});
  }

  // ============ INICIALIZAÇÃO ============
  async function init() {
    log('Inicializando content script...');

    const sync = await chrome.storage.sync.get({ isExtensionActive: true, isAIActive: false, isModalActive: false, isVerifyActive: false, xaigooModalTheme: 'light' });
    isExtensionActive = sync.isExtensionActive ?? true;
    isAIActive = sync.isAIActive ?? false;
    isModalActive = sync.isModalActive ?? false;
    isVerifyActive = sync.isVerifyActive ?? false;
    modalTheme = sync.xaigooModalTheme || 'light';

    log('Estado carregado:', { isExtensionActive, isAIActive, isModalActive, isVerifyActive });

    if (!isExtensionActive) {
      log('Extensão desligada - não iniciando captura');
      return;
    }

    startCapture();
  }

  // ============ CAPTURA ============
  function startCapture() {
    log('Iniciando captura de perfis');

    seenUsernames.clear();
    sendQueue = [];

    const initialCount = scanAndQueue();
    log('Scan inicial encontrou', initialCount, 'perfis');

    // MutationObserver para detectar novos elementos no DOM
    observer = new MutationObserver((mutations) => {
      if (!isExtensionActive) return;
      let changed = false;
      for (const m of mutations) {
        if (m.addedNodes.length > 0) { changed = true; break; }
      }
      if (changed) {
        scanAndQueue();
      }
    });

    observer.observe(document.body, { childList: true, subtree: true });

    // Scan periódico como fallback
    scanInterval = setInterval(() => {
      if (isExtensionActive) scanAndQueue();
    }, 2000);

    // Verifica periodicamente se há novos containers scrolláveis (modais)
    setupScrollListener();

    if (isModalActive) {
      injectModal();
      if (modalStatsInterval) clearInterval(modalStatsInterval);
      modalStatsInterval = setInterval(updateModalStats, 10000);
      updateModalStats();
    }

    processQueue();
  }

  // ============ DETECÇÃO DO MODAL DE SEGUIDORES ============
  function setupScrollListener() {
    const attachedElements = new WeakSet();

    const findAndAttachScrollable = () => {
      // Instagram usa role="dialog" para o modal de seguidores
      const dialogs = document.querySelectorAll('div[role="dialog"]');

      for (const dialog of dialogs) {
        // Verifica se é o modal de seguidores (contém links de perfis)
        const hasProfileLinks = dialog.querySelector('a[href^="/"]');
        if (!hasProfileLinks) continue;

        // Encontra o container scrollável dentro do dialog
        // Instagram geralmente tem um div com overflow auto/scroll dentro do dialog
        const scrollables = dialog.querySelectorAll('div');
        for (const el of scrollables) {
          if (attachedElements.has(el)) continue;

          const style = window.getComputedStyle(el);
          const isScrollable =
            (style.overflowY === 'auto' || style.overflowY === 'scroll') &&
            el.scrollHeight > el.clientHeight;

          if (isScrollable) {
            attachedElements.add(el);
            el.addEventListener('scroll', onModalScroll, { passive: true });
            log('✅ Scroll listener anexado a container scrollável do modal de seguidores');
          }
        }

        // Também escuta scroll no próprio dialog
        if (!attachedElements.has(dialog)) {
          attachedElements.add(dialog);
          dialog.addEventListener('scroll', onModalScroll, { passive: true });
        }
      }
    };

    // Debounce para o scroll não disparar scan a cada pixel
    let scrollDebounce = null;
    function onModalScroll() {
      if (!isExtensionActive) return;
      if (scrollDebounce) clearTimeout(scrollDebounce);
      scrollDebounce = setTimeout(() => {
        const count = scanAndQueue();
        if (count > 0) {
          log('Scroll detectou', count, 'novos perfis');
        }
      }, 300);
    }

    // Executa imediatamente e repete periodicamente
    findAndAttachScrollable();
    scrollCheckInterval = setInterval(findAndAttachScrollable, 1500);
  }

  function stopCapture() {
    log('Parando captura');
    if (observer) { observer.disconnect(); observer = null; }
    if (scanInterval) { clearInterval(scanInterval); scanInterval = null; }
    if (scrollCheckInterval) { clearInterval(scrollCheckInterval); scrollCheckInterval = null; }
    if (modalStatsInterval) { clearInterval(modalStatsInterval); modalStatsInterval = null; }
    removeModal();
  }

  // ============ EXTRAÇÃO DE PERFIS DO MODAL ============
  function extractFollowersFromModal() {
    const results = [];
    const nonProfile = new Set([
      'p', 'reels', 'explore', 'direct', 'accounts', 'stories', 'tv', 'reel',
      'login', 'signup', 'help', 'about', 'privacy', 'terms', 'directory',
      'tags', 'locations', 'highlights', 'messages', 'notifications',
      'create', 'edit', 'invite', 'contacts', 'following', 'followers',
      'saved', 'archive', 'closefriends', 'thread', 'settings',
    ]);

    // Busca links APENAS dentro de dialogs (modal de seguidores)
    const dialogs = document.querySelectorAll('div[role="dialog"]');
    log(`Dialogs encontrados: ${dialogs.length}`);

    for (const dialog of dialogs) {
      const links = dialog.querySelectorAll('a[href^="/"]');
      log(`Links no dialog: ${links.length}`);
      for (const a of links) {
        const result = extractProfileFromLink(a, nonProfile);
        if (result) {
          results.push(result);
        }
      }
    }

    // Deduplica por username
    const unique = [];
    const seen = new Set();
    for (const r of results) {
      if (!seen.has(r.username)) {
        seen.add(r.username);
        unique.push(r);
      }
    }

    log(`Perfis extraídos: ${unique.length}`);
    return unique;
  }

  function isPrivateAccount(a) {
    // Instagram exibe badge/ícone de conta fechada no modal de seguidores.
    // Sinais: texto "Solicitar seguir" em PT-BR, ícone de candado (svg com aria-label contendo "lock" ou "private").
    const row = a.closest('[role="listitem"], li, div[class*="row"], div[class*="item"]') || a.parentElement;
    const text = (row ? row.textContent : '') + ' ' + (a.textContent || '');
    const lower = text.toLowerCase();

    if (lower.includes('solicitar seguir') || lower.includes('siga') && lower.includes('para ver')) {
      return true;
    }

    // Ícones de candado/privacidade (SVG aria-label)
    const icons = row ? row.querySelectorAll('svg, [aria-label]') : [];
    for (const ic of icons) {
      const label = (ic.getAttribute('aria-label') || '').toLowerCase();
      if (label.includes('lock') || label.includes('private') || label.includes('privada') || label.includes('candado')) {
        return true;
      }
    }

    return false;
  }

  function hasMessageButton(a) {
    // Verifica se a linha do perfil contém botão "Enviar mensagem" (PT-BR) ou "Message".
    const row = a.closest('[role="listitem"], li, div[class*="row"], div[class*="item"]') || a.parentElement;
    if (!row) return false;
    const buttons = row.querySelectorAll('button, a, [role="button"], span, div');
    for (const btn of buttons) {
      const text = (btn.textContent || '').trim().toLowerCase();
      if (text.includes('enviar mensagem') || text.includes('message') || text.includes('mensage')) {
        return true;
      }
    }
    // fallback: procurar por qualquer elemento que contenha "enviar" e "mensagem"
    const allText = row.textContent || '';
    if (/enviar.*mensagem/i.test(allText)) return true;
    return false;
  }

  function extractProfileFromLink(a, nonProfile) {
    const href = a.getAttribute('href') || '';
    if (!href.startsWith('/')) return null;

    // Extrai o slug (username) do href
    const slug = href.split('?')[0].replace(/^\//, '').replace(/\/$/, '');
    if (!slug || slug.length < 1 || slug.length > 30) return null;

    // Filtra links que não são perfis
    if (nonProfile.has(slug.toLowerCase())) return null;

    // Rejeita paths com / (sub-rotas como /p/abc123)
    if (slug.includes('/')) return null;

    // Rejeita slugs com ponto (exceto usernames válidos do Instagram)
    // Instagram permite pontos em usernames, mas não em caminhos internos
    // Verifica: se contém ponto E parece extensão de arquivo → rejeita
    if (/\.\w{2,4}$/.test(slug)) return null;

    // Username do Instagram: letras, números, underscore, ponto (max 30 chars)
    if (!/^[a-zA-Z0-9_.]+$/.test(slug)) return null;

    // Verifica se o link está visível no viewport (não está oculto)
    const rect = a.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return null;

    // IGNORA contas fechadas/privadas — apenas captura perfis abertos
    if (isPrivateAccount(a)) return null;

    return {
      username: slug,
      profile_url: `https://www.instagram.com/${slug}/`,
      has_message_button: hasMessageButton(a), // true se a linha tem botão "Enviar mensagem"
    };
  }

  function scanAndQueue() {
    if (!isExtensionActive) return 0;
    let newProfiles;
    try {
      newProfiles = extractFollowersFromModal();
    } catch (e) {
      log('Erro ao extrair perfis:', e.message);
      return 0;
    }
    if (!Array.isArray(newProfiles)) {
      log('extractFollowersFromModal não retornou um array:', typeof newProfiles);
      return 0;
    }
    const trulyNew = newProfiles.filter(p => !seenUsernames.has(p.username));
    if (trulyNew.length > 0) {
      log(`${trulyNew.length} novos perfis detectados (total fila: ${sendQueue.length})`);
      for (const p of trulyNew) {
        seenUsernames.add(p.username);
        if (isVerifyActive) {
          // Verifica visibilidade do perfil via backend (cURL server-side)
          chrome.runtime.sendMessage({ type: 'CHECK_PROFILE_VISIBILITY', profileUrl: p.profile_url }, (response) => {
            if (chrome.runtime.lastError) {
              log('Erro na verificação de visibilidade:', chrome.runtime.lastError.message);
              return;
            }
            if (response && response.success !== undefined) {
              // Armazena resultado no perfil para usar após o save
              p._serverVisibility = response.hasMessageButton ?? response.success;
              log(`Visibilidade de ${p.username}: ${p._serverVisibility ? 'aberto' : 'fechado'}`);
            }
          });
        }
        sendQueue.push(p);
      }
      if (!isProcessingQueue) processQueue();
    }
    return trulyNew.length;
  }

  // ============ FILA DE ENVIO (via background) ============
  async function processQueue() {
    if (isProcessingQueue || sendQueue.length === 0) {
      return;
    }

    isProcessingQueue = true;
    log('Processando fila:', sendQueue.length, 'itens');

    while (sendQueue.length > 0) {
      if (!isExtensionActive) {
        log('Extensão desligada - pausando fila');
        break;
      }

      const profile = sendQueue.shift();
      try {
        const response = await saveLead(profile);

        if (response.success) {
          if (!response.duplicate) {
            sessionCount++;
            if (response.segmentation_level === 1) sessionLevel1++;
            else if (response.segmentation_level === 2) sessionLevel2++;
            incrementCounter();
          }
          log(`✅ Salvo: ${profile.username} | Dup: ${response.duplicate || false} | Total sessão: ${sessionCount}`);
          if (modalEl) updateModalStats();

          // Atualiza visibilidade no banco após o save (precisa do id)
          const influencerId = response.id;
          if (influencerId && isVerifyActive) {
            // Usa resultado do check server-side se disponível, senão usa o DOM check
            const visibility = profile._serverVisibility !== undefined
              ? profile._serverVisibility
              : (profile.has_message_button ?? null);
            if (visibility !== null && visibility !== undefined) {
              chrome.runtime.sendMessage({
                type: 'UPDATE_VISIBILITY',
                influencerId: influencerId,
                hasMessageButton: !!visibility,
              }, (resp) => {
                if (chrome.runtime.lastError) {
                  log('Erro ao atualizar visibilidade:', chrome.runtime.lastError.message);
                  return;
                }
                log(`🔍 Visibilidade de ${profile.username} (${influencerId}): ${visibility ? 'aberto' : 'fechado'} — salvo no banco`);
              });
            }
          }
        } else {
          log(`❌ Erro do servidor para ${profile.username}: ${response.error}`);
          // Retentar se não é erro de autenticação
          if (response.error && !response.error.includes('sessão') && !response.error.includes('401')) {
            profile._retry = (profile._retry || 0) + 1;
            if (profile._retry <= 3) {
              sendQueue.push(profile); // Coloca no final da fila
            }
          }
        }
      } catch (err) {
        log(`❌ Erro ao enviar perfil ${profile.username}:`, err.message);
        profile._retry = (profile._retry || 0) + 1;
        if (profile._retry <= 3) {
          sendQueue.push(profile);
        }
      }

      // Delay entre envios para não sobrecarregar o servidor
      await sleep(400);
    }

    isProcessingQueue = false;

    // Se novos itens entraram na fila durante o processamento
    if (sendQueue.length > 0) {
      setTimeout(processQueue, 200);
    }
  }

  function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

  // ============ STORAGE LISTENER ============
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync') return;
    if (changes.isExtensionActive) {
      isExtensionActive = changes.isExtensionActive.newValue;
      log('Toggle mestre alterado:', isExtensionActive);
      if (!isExtensionActive) stopCapture();
      else if (isExtensionActive) startCapture();
    }
    if (changes.isAIActive) {
      isAIActive = changes.isAIActive.newValue;
      log('Toggle IA alterado:', isAIActive);
    }
    if (changes.isModalActive) {
      isModalActive = changes.isModalActive.newValue;
      log('Toggle modal alterado:', isModalActive);
      if (isModalActive && isExtensionActive) {
        injectModal();
        if (modalStatsInterval) clearInterval(modalStatsInterval);
        modalStatsInterval = setInterval(updateModalStats, 10000);
        updateModalStats();
      } else {
        removeModal();
        if (modalStatsInterval) { clearInterval(modalStatsInterval); modalStatsInterval = null; }
      }
    }
    if (changes.isVerifyActive) {
      isVerifyActive = changes.isVerifyActive.newValue;
      log('Toggle verificação alterado:', isVerifyActive);
    }
    if (changes.xaigooModalTheme) {
      modalTheme = changes.xaigooModalTheme.newValue || 'light';
      log('Tema do modal alterado:', modalTheme);
      updateModalTheme();
      updateThemeIcon();
    }
  });

  // ============ MODAL FLUTUANTE (arrastável) ============
  function injectModal() {
    if (modalEl) return;

    modalEl = document.createElement('div');
    modalEl.id = 'xaigoo-extractor-modal';
    modalEl.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 2147483647;
      width: 260px;
      background: #ffffff;
      border: 1px solid #e5e7eb;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.15);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      display: flex;
      flex-direction: column;
      cursor: default;
      user-select: none;
    `;

    modalEl.innerHTML = `
      <div id="xaigoo-modal-header" style="padding: 10px 16px; border-bottom: 1px solid #f3f4f6; display: flex; justify-content: space-between; align-items: center; cursor: move;">
        <div style="display:flex; align-items:center; gap:8px;">
          <img id="xaigoo-modal-logo" src="${chrome.runtime.getURL('logo-xaigoo-modal.png')}" style="height:28px; width:auto; transition: filter 0.3s;" alt="Xaigoo">
          <span id="xaigoo-modal-title" style="font-weight: 700; font-size: 13px; color: #111827; transition: color 0.3s;">Xaigoo Extractor</span>
        </div>
        <div style="display:flex; align-items:center; gap:2px;">
          <button id="xaigoo-modal-theme-toggle" title="Alternar tema claro/escuro" style="background: none; border: 1px solid transparent; cursor: pointer; padding: 5px; line-height: 0; display: flex; align-items: center; justify-content: center; border-radius: 6px; transition: background 0.2s, border-color 0.2s;">
            <span id="xaigoo-theme-icon" style="display:flex;"></span>
          </button>
          <button id="xaigoo-modal-close" title="Fechar modal" style="background: none; border: 1px solid transparent; cursor: pointer; font-size: 18px; color: #9ca3af; padding: 2px 5px; line-height: 1; border-radius: 6px; transition: background 0.2s, border-color 0.2s;">×</button>
        </div>
      </div>
      <div id="xaigoo-modal-body" style="padding: 14px 16px; transition: background 0.3s;">
        <div id="xaigoo-modal-label" style="font-size: 11px; color: #475569; margin-bottom: 10px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; transition: color 0.3s;">Leads capturados</div>
        <div id="xaigoo-modal-total" style="font-size: 32px; font-weight: 800; color: #1e1b4b; margin-bottom: 12px; transition: color 0.3s;">0</div>
        <div id="xaigoo-modal-segmentacao" style="display: flex; gap: 8px; font-size: 12px;">
          <div id="xaigoo-seg-level1" style="flex:1; background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 8px; padding: 8px; color: #065f46; text-align: center; transition: background 0.3s, border-color 0.3s, color 0.3s;">
            <div style="font-weight:700; font-size: 14px;">0</div>
            <div id="xaigoo-seg-label1" style="font-size: 10px; color: inherit; opacity: 0.85;">Nível 1</div>
          </div>
          <div id="xaigoo-seg-level2" style="flex:1; background: #fffbeb; border: 1px solid #fde68a; border-radius: 8px; padding: 8px; color: #78350f; text-align: center; transition: background 0.3s, border-color 0.3s, color 0.3s;">
            <div style="font-weight:700; font-size: 14px;">0</div>
            <div id="xaigoo-seg-label2" style="font-size: 10px; color: inherit; opacity: 0.85;">Nível 2</div>
          </div>
        </div>
        <div id="xaigoo-modal-ai-off" style="margin-top: 8px; padding: 8px; background: #f1f5f9; border-radius: 6px; font-size: 11px; color: #475569; text-align: center; display: none; transition: background 0.3s, color 0.3s;">
          IA desligada — exibindo apenas total de leads
        </div>
      </div>
      <div id="xaigoo-modal-footer" style="padding: 10px 16px; border-top: 1px solid #f3f4f6; font-size: 11px; color: #94a3b8; text-align: center; transition: color 0.3s, border-color 0.3s;">
        Xaigoo • Extensão de prospecção
      </div>
    `;

    document.body.appendChild(modalEl);

    // Botão fechar
    modalEl.querySelector('#xaigoo-modal-close').addEventListener('click', () => {
      modalEl.style.display = 'none';
    });

    // Toggle de tema dark/light
    const themeBtn = modalEl.querySelector('#xaigoo-modal-theme-toggle');
    themeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      modalTheme = modalTheme === 'dark' ? 'light' : 'dark';
      chrome.storage.sync.set({ xaigooModalTheme: modalTheme });
      updateThemeIcon();
      updateModalTheme();
      log('Tema do modal alterado manualmente:', modalTheme);
    });

    // Hover effects nos botões do header
    [themeBtn, modalEl.querySelector('#xaigoo-modal-close')].forEach(btn => {
      btn.addEventListener('mouseenter', () => {
        btn.style.background = modalTheme === 'dark' ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.05)';
        btn.style.borderColor = modalTheme === 'dark' ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.08)';
      });
      btn.addEventListener('mouseleave', () => {
        btn.style.background = 'none';
        btn.style.borderColor = 'transparent';
      });
    });

    // Aplica tema e ícone iniciais
    updateThemeIcon();
    updateModalTheme();

    setupDrag(modalEl, modalEl.querySelector('#xaigoo-modal-header'));
  }

  function setupDrag(el, handle) {
    let isDown = false;
    let startX, startY, startLeft, startTop;

    handle.addEventListener('mousedown', (e) => {
      isDown = true;
      startX = e.clientX;
      startY = e.clientY;
      const rect = el.getBoundingClientRect();
      startLeft = rect.left;
      startTop = rect.top;
      el.style.transition = 'none';
      e.preventDefault();
    });

    window.addEventListener('mousemove', (e) => {
      if (!isDown) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      el.style.left = `${startLeft + dx}px`;
      el.style.top = `${startTop + dy}px`;
      el.style.right = 'auto';
      el.style.bottom = 'auto';
    });

    window.addEventListener('mouseup', () => {
      isDown = false;
    });
  }

  function removeModal() {
    if (modalEl) {
      modalEl.remove();
      modalEl = null;
    }
  }

  // ============ TEMA DO MODAL (controle manual dark/light) ============

  /**
   * Atualiza o ícone do toggle de tema (sol = dark ativo, lua = light ativo).
   * Padrão UX: mostra o ícone do modo OPOSTO (o que será ativado ao clicar).
   */
  function updateThemeIcon() {
    const iconEl = document.getElementById('xaigoo-theme-icon');
    if (!iconEl) return;

    if (modalTheme === 'dark') {
      // Mostrar ícone de sol (para voltar ao light) — amarelo dourado
      iconEl.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fbbf24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>';
    } else {
      // Mostrar ícone de lua (para ativar dark) — índigo/roxo
      iconEl.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#6366f1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
    }
  }

  /**
   * Aplica o tema completo ao modal flutuante.
   * Paleta dark: Slate 900 base com contraste WCAG AA em todos os textos.
   * Paleta light: Branco puro com tons índigo/slate para legibilidade máxima.
   * Logo: filtro branco (dark) / filtro roxo-índigo (light).
   */
  function updateModalTheme() {
    if (!modalEl) return;
    const isDark = modalTheme === 'dark';

    // Referências a todos os elementos tematizáveis
    const logo      = document.getElementById('xaigoo-modal-logo');
    const header    = document.getElementById('xaigoo-modal-header');
    const title     = document.getElementById('xaigoo-modal-title');
    const body      = document.getElementById('xaigoo-modal-body');
    const label     = document.getElementById('xaigoo-modal-label');
    const totalEl   = document.getElementById('xaigoo-modal-total');
    const level1    = document.getElementById('xaigoo-seg-level1');
    const level2    = document.getElementById('xaigoo-seg-level2');
    const aiOffBox  = document.getElementById('xaigoo-modal-ai-off');
    const footer    = document.getElementById('xaigoo-modal-footer');
    const closeBtn  = document.getElementById('xaigoo-modal-close');

    if (isDark) {
      // ── DARK MODE ──────────────────────────────────────────────────
      // Base: Slate-900 (#0f172a) — profundidade sem ser pure black
      modalEl.style.background = '#0f172a';
      modalEl.style.borderColor = '#1e293b';
      modalEl.style.boxShadow = '0 12px 32px rgba(0,0,0,0.55)';

      // Header
      if (header) header.style.borderColor = '#1e293b';
      if (title) title.style.color = '#f1f5f9'; // Slate-100 — contraste 15.4:1

      // Logo: branco (sem filtro)
      if (logo) {
        logo.src = chrome.runtime.getURL('logo-xaigoo-modal-white.png');
        logo.style.filter = 'none';
      }

      // Labels e contadores
      if (label) label.style.color = '#94a3b8'; // Slate-400 — contraste 5.5:1 sobre #0f172a
      if (totalEl) totalEl.style.color = '#f1f5f9'; // Slate-100

      // Cards de segmentação — fundos saturados escuros com texto claro
      if (level1) {
        level1.style.background = '#064e3b'; // Emerald-900
        level1.style.borderColor = '#065f46'; // Emerald-800
        level1.style.color = '#6ee7b7';       // Emerald-300 — contraste 7.2:1
      }
      if (level2) {
        level2.style.background = '#451a03'; // Amber-950
        level2.style.borderColor = '#78350f'; // Amber-800
        level2.style.color = '#fcd34d';       // Amber-300 — contraste 8.1:1
      }

      // AI off box
      if (aiOffBox) {
        aiOffBox.style.background = '#1e293b'; // Slate-800
        aiOffBox.style.color = '#94a3b8';       // Slate-400
      }

      // Footer
      if (footer) {
        footer.style.borderColor = '#1e293b';
        footer.style.color = '#64748b'; // Slate-500 — contraste 4.6:1
      }

      // Botão fechar
      if (closeBtn) closeBtn.style.color = '#64748b';

    } else {
      // ── LIGHT MODE ─────────────────────────────────────────────────
      // Base: Pure white
      modalEl.style.background = '#ffffff';
      modalEl.style.borderColor = '#e2e8f0';
      modalEl.style.boxShadow = '0 10px 25px rgba(0,0,0,0.12)';

      // Header
      if (header) header.style.borderColor = '#f1f5f9';
      if (title) title.style.color = '#1e1b4b'; // Indigo-950 — brand purple-dark

      // Logo: filtro roxo-índigo (brand)
      if (logo) {
        logo.src = chrome.runtime.getURL('logo-xaigoo-modal.png');
        logo.style.filter = 'brightness(0) saturate(100%) invert(27%) sepia(51%) hue-rotate(200deg) saturate(300%) brightness(90%) contrast(80%)';
      }

      // Labels e contadores
      if (label) label.style.color = '#475569'; // Slate-600 — contraste 7.0:1
      if (totalEl) totalEl.style.color = '#1e1b4b'; // Indigo-950

      // Cards de segmentação — fundos claros pastéis com texto escuro
      if (level1) {
        level1.style.background = '#ecfdf5'; // Emerald-50
        level1.style.borderColor = '#a7f3d0'; // Emerald-200
        level1.style.color = '#065f46';       // Emerald-800 — contraste 7.5:1
      }
      if (level2) {
        level2.style.background = '#fffbeb'; // Amber-50
        level2.style.borderColor = '#fde68a'; // Amber-200
        level2.style.color = '#78350f';       // Amber-800 — contraste 8.6:1
      }

      // AI off box
      if (aiOffBox) {
        aiOffBox.style.background = '#f1f5f9'; // Slate-100
        aiOffBox.style.color = '#475569';       // Slate-600
      }

      // Footer
      if (footer) {
        footer.style.borderColor = '#f1f5f9';
        footer.style.color = '#94a3b8'; // Slate-400
      }

      // Botão fechar
      if (closeBtn) closeBtn.style.color = '#9ca3af';
    }
  }

  async function updateModalStats() {
    if (!modalEl) return;
    if (!isExtensionActive) {
      modalEl.style.display = 'none';
      return;
    }
    modalEl.style.display = 'flex';

    // Atualiza tema antes de mostrar
    updateModalTheme();

    const totalEl = document.getElementById('xaigoo-modal-total');
    if (totalEl) totalEl.textContent = sessionCount || 0;

    const segBox = document.getElementById('xaigoo-modal-segmentacao');
    const aiOffBox = document.getElementById('xaigoo-modal-ai-off');

    if (!isAIActive) {
      if (segBox) segBox.style.display = 'none';
      if (aiOffBox) aiOffBox.style.display = 'block';
    } else {
      if (segBox) segBox.style.display = 'flex';
      if (aiOffBox) aiOffBox.style.display = 'none';

      if (segBox) {
        const l1El = segBox.children[0]?.querySelector('div:first-child');
        const l2El = segBox.children[1]?.querySelector('div:first-child');
        if (l1El) l1El.textContent = sessionLevel1 ?? 0;
        if (l2El) l2El.textContent = sessionLevel2 ?? 0;
      }
    }
  }

  // ============ BOOT ============
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();