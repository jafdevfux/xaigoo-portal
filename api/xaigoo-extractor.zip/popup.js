// Xaigoo Extractor - Popup (toggles + login/logout + counter)
(function () {
  'use strict';

  const els = {
    toggleMaster: document.getElementById('toggleMaster'),
    toggleAI: document.getElementById('toggleAI'),
    toggleModal: document.getElementById('toggleModal'),
    toggleVerify: document.getElementById('toggleVerify'),
    status: document.getElementById('status'),
    loginForm: document.getElementById('loginForm'),
    loginUser: document.getElementById('loginUser'),
    loginUserName: document.getElementById('loginUserName'),
    loginEmail: document.getElementById('loginEmail'),
    loginPassword: document.getElementById('loginPassword'),
    btnLogin: document.getElementById('btnLogin'),
    btnLogout: document.getElementById('btnLogout'),
    loginErr: document.getElementById('loginErr'),
  };

  function setStatus(text, isError) {
    els.status.textContent = text;
    els.status.style.color = isError ? '#f87171' : '#94a3b8';
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function renderSession(user) {
    if (user) {
      els.loginForm.classList.add('hidden');
      els.loginUser.classList.remove('hidden');
      els.loginUserName.textContent = escapeHtml(user.name || user.email || 'Logado');
      els.loginUserName.title = escapeHtml(user.email || '');
      els.btnLogout.classList.remove('hidden');
      setStatus('Sessão ativa');
    } else {
      els.loginForm.classList.remove('hidden');
      els.loginUser.classList.add('hidden');
      els.loginUserName.textContent = 'Logado';
      els.btnLogout.classList.add('hidden');
      els.loginErr.style.display = 'none';
      setStatus('Pronto');
    }
  }

  function loadState() {
    chrome.storage.sync.get({ isExtensionActive: true, isAIActive: false, isModalActive: false, isVerifyActive: false }, (sync) => {
      els.toggleMaster.checked = sync.isExtensionActive;
      els.toggleAI.checked = sync.isAIActive;
      els.toggleModal.checked = sync.isModalActive;
      els.toggleVerify.checked = sync.isVerifyActive;
    });
  }

  function loadSession() {
    chrome.runtime.sendMessage({ type: 'GET_SESSION_ID' }, (resp) => {
      const id = resp && resp.sessionId;
      if (id) {
        // Sessão salva — tenta buscar dados do usuário via /me
        fetch('https://api.xaigoo.app/api/auth/me', {
          credentials: 'include',
          headers: { 'X-Xaigoo-Session': id },
        })
          .then(r => r.json())
          .then(data => {
            if (data && data.id) {
              renderSession({ name: data.name, email: data.email });
            } else {
              renderSession({ email: '(salvo)' });
            }
          })
          .catch(() => renderSession({ email: '(salvo)' }));
      } else {
        renderSession(null);
      }
    });
  }

  els.toggleMaster.addEventListener('change', () => {
    const v = els.toggleMaster.checked;
    chrome.storage.sync.set({ isExtensionActive: v }, () => {
      setStatus(v ? 'Extensão ligada' : 'Extensão desligada');
    });
  });
  els.toggleAI.addEventListener('change', () => {
    chrome.storage.sync.set({ isAIActive: els.toggleAI.checked }, () => {});
  });
  els.toggleModal.addEventListener('change', () => {
    chrome.storage.sync.set({ isModalActive: els.toggleModal.checked }, () => {});
  });
  els.toggleVerify.addEventListener('change', () => {
    chrome.storage.sync.set({ isVerifyActive: els.toggleVerify.checked }, () => {});
  });

  els.btnLogin.addEventListener('click', async () => {
    const email = els.loginEmail.value.trim();
    const password = els.loginPassword.value;
    if (!email || !password) {
      els.loginErr.textContent = 'Preencha e-mail e senha.';
      els.loginErr.style.display = 'block';
      return;
    }
    els.loginErr.style.display = 'none';
    els.btnLogin.disabled = true;
    setStatus('Entrando...');
    try {
      const resp = await new Promise((resolve) => {
        chrome.runtime.sendMessage({ type: 'LOGIN', email, password }, resolve);
      });
      if (resp && resp.success) {
        setStatus('Logado com sucesso');
        renderSession(resp.user);
        els.loginEmail.value = '';
        els.loginPassword.value = '';
      } else {
        els.loginErr.textContent = (resp && resp.error) ? resp.error : 'Falha ao entrar.';
        els.loginErr.style.display = 'block';
        setStatus('Falha ao entrar', true);
      }
    } catch (e) {
      els.loginErr.textContent = e.message;
      els.loginErr.style.display = 'block';
    } finally {
      els.btnLogin.disabled = false;
    }
  });

  els.loginPassword.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') els.btnLogin.click();
  });

  els.btnLogout.addEventListener('click', async () => {
    try {
      await new Promise((resolve) => {
        chrome.runtime.sendMessage({ type: 'LOGOUT' }, resolve);
      });
    } catch (e) {}
    renderSession(null);
    setStatus('Deslogado');
  });

  loadState();
  loadSession();
  setStatus('Pronto');
})();