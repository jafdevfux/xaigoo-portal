// Xaigoo Extractor - Background Service Worker (MV3)
// API remota (PHP + banco na HomeHost) — mesmo endpoint que o portal web em produção
const API_BASE = 'https://api.xaigoo.app/api/save_lead.php';
const AUTH_BASE = 'https://api.xaigoo.app/api/auth/login';

// Fila sequencial para verificação de visibilidade de perfis
let visibilityQueue = [];
let isProcessingVisibility = false;

function processVisibilityQueue() {
  if (isProcessingVisibility || visibilityQueue.length === 0) return;
  isProcessingVisibility = true;
  const item = visibilityQueue.shift();
  const { profileUrl, sendResponse } = item;

  console.log('[Xaigoo Extractor background] Verificando visibilidade:', profileUrl);
  
  // Timeout de segurança: se não carregar em 15s, aborta
  const timeoutId = setTimeout(() => {
    console.log('[Xaigoo Extractor background] Timeout ao verificar:', profileUrl);
    sendResponse({ success: false, error: 'timeout' });
    isProcessingVisibility = false;
    processVisibilityQueue();
  }, 15000);

  chrome.tabs.create({ url: profileUrl, active: false }, (tab) => {
    const listener = (tabId, changeInfo) => {
      if (tabId === tab.id && changeInfo.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        clearTimeout(timeoutId);
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            const buttons = Array.from(document.querySelectorAll('button, a, [role="button"]'));
            const hasMessage = buttons.some(b => {
              const text = b.textContent.trim().toLowerCase();
              return text.includes('send message') || text.includes('enviar mensagem') || text.includes('message');
            });
            return hasMessage;
          }
        }, (results) => {
          chrome.tabs.remove(tab.id, () => {
            const result = results && results[0] ? true : false;
            console.log('[Xaigoo Extractor background] Resultado:', result, 'para', profileUrl);
            sendResponse({ success: result });
            isProcessingVisibility = false;
            processVisibilityQueue(); // Próximo
          });
        });
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function getStoredSessionId() {
  return new Promise((resolve) => {
    chrome.storage.sync.get({ xaigoo_session_id: null }, (data) => resolve(data.xaigoo_session_id || null));
  });
}

async function login(email, password) {
  try {
    const response = await fetch(AUTH_BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'omit',
      body: JSON.stringify({ email, password }),
    });
    const data = await response.json().catch(() => null);

    if (!response.ok) {
      return { success: false, error: (data && data.error) ? data.error : ('HTTP ' + response.status) };
    }
    if (!data || !data.id) {
      return { success: false, error: data && data.error ? data.error : 'Resposta inválida do servidor.' };
    }
    if (data.sessionId) {
      await chrome.storage.sync.set({ xaigoo_session_id: data.sessionId });
    }
    return { success: true, user: { id: data.id, name: data.name, email: data.email } };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

async function logout() {
  await chrome.storage.sync.remove('xaigoo_session_id');
  return { success: true };
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({ isExtensionActive: true, isAIActive: false, isModalActive: false, isVerifyActive: false }, () => {});
  chrome.storage.session.set({ sentCount: 0 }, () => {});
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) return;

  if (message.type === 'LOGIN') {
    login(message.email, message.password).then(sendResponse);
    return true;
  }
  if (message.type === 'LOGOUT') {
    logout().then(sendResponse);
    return true;
  }
  if (message.type === 'GET_SESSION_ID') {
    getStoredSessionId().then((id) => sendResponse({ sessionId: id }));
    return true;
  }
  if (message.type === 'GET_USER') {
    (async () => {
      const sessionId = await getStoredSessionId();
      if (!sessionId) { sendResponse({ success: false }); return; }
      try {
        const response = await fetch('https://api.xaigoo.app/api/auth/me', {
          method: 'GET',
          headers: { 'X-Xaigoo-Session': sessionId },
          credentials: 'omit',
        });
        const data = await response.json();
        sendResponse({ success: response.ok, ...data });
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }
  if (message.type === 'GET_SESSION_COOKIE') {
    getStoredSessionId().then((id) => sendResponse({ cookie: id }));
    return true;
  }

  if (message.type === 'CHECK_PROFILE_VISIBILITY') {
    // Fazer chamada para o backend em vez de abrir uma guia
    (async () => {
      const sessionId = await getStoredSessionId();
      if (!sessionId) {
        sendResponse({ success: false, error: 'Não autenticado.' });
        return;
      }
      
      try {
        const response = await fetch('https://api.xaigoo.app/api/profile/verify-visibility', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Xaigoo-Session': sessionId,
          },
          body: JSON.stringify({ profileUrl: message.profileUrl }),
        });
        
        const data = await response.json();
        sendResponse({ 
          success: data.success, 
          hasMessageButton: data.hasMessageButton,
          error: data.error 
        });
      } catch (error) {
        sendResponse({ 
          success: false, 
          error: error.message,
          hasMessageButton: false 
        });
      }
    })();
    return true;
  }

  if (message.type === 'SAVE_LEAD') {
    (async () => {
      const sessionId = await getStoredSessionId();
      if (!sessionId) {
        sendResponse({ success: false, error: 'Não autenticado. Faça login na extensão.' });
        return;
      }
      try {
        const response = await fetch(API_BASE, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Xaigoo-Session': sessionId,
          },
          credentials: 'omit',
          body: JSON.stringify({
            username: message.profile.username,
            profile_url: message.profile.profile_url,
            ai_enabled: message.ai_enabled,
            has_message_button: message.profile.has_message_button ?? null,
          }),
        });
        const text = await response.text();
        let data;
        try { data = JSON.parse(text); } catch (e) { data = null; }
        if (!data) {
          sendResponse({ success: false, error: 'Servidor retornou HTTP ' + response.status + ' (não-JSON).' });
          return;
        }
        if (data.success && !data.duplicate) {
          chrome.storage.session.get({ sentCount: 0 }, (d) => {
            chrome.storage.session.set({ sentCount: (d.sentCount || 0) + 1 });
          });
        }
        sendResponse(Object.assign({ httpStatus: response.status }, data));
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }

  if (message.type === 'UPDATE_VISIBILITY') {
    (async () => {
      const sessionId = await getStoredSessionId();
      if (!sessionId) {
        sendResponse({ success: false, error: 'Não autenticado.' });
        return;
      }
      try {
        const id = encodeURIComponent(message.influencerId);
        const url = `https://api.xaigoo.app/api/influencers/${id}/visibility`;
        const response = await fetch(url, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            'X-Xaigoo-Session': sessionId,
          },
          credentials: 'omit',
          body: JSON.stringify({ hasMessageButton: message.hasMessageButton }),
        });
        const data = await response.json().catch(() => null);
        sendResponse(data || { success: response.ok });
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }

  if (message.type === 'GET_STATS') {
    (async () => {
      const sessionId = await getStoredSessionId();
      if (!sessionId) {
        sendResponse({ success: false, error: 'Não autenticado.' });
        return;
      }
      try {
        const url = API_BASE + '?stats=1&session_id=' + encodeURIComponent(sessionId);
        const response = await fetch(url, {
          method: 'GET',
          headers: { 'X-Xaigoo-Session': sessionId },
          credentials: 'omit',
        });
        const text = await response.text();
        let data;
        try { data = JSON.parse(text); } catch (e) { data = null; }
        if (!data) {
          sendResponse({ success: false, error: 'Resposta não-JSON' });
          return;
        }
        sendResponse(data);
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }

  if (message.type === 'INCREMENT_COUNTER') {
    chrome.storage.session.get({ sentCount: 0 }, (data) => {
      chrome.storage.session.set({ sentCount: (data.sentCount || 0) + 1 });
    });
    return true;
  }

  if (message.type === 'GET_COUNTER') {
    chrome.storage.session.get({ sentCount: 0 }, (data) => {
      sendResponse({ sentCount: data.sentCount || 0 });
    });
    return true;
  }
});