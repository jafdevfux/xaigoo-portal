# Xaigoo Extractor - Extensão Chrome para Prospecção de Leads Instagram

Extensão Manifest V3 para capturar perfis de seguidores do Instagram de forma segura (scroll manual) e enviá-los para o backend do pipeline Xaigoo com qualificação opcional via IA (DeepSeek).

## 📁 Estrutura

```
xaigoo-extractor/
├── manifest.json      # Manifest V3
├── popup.html         # Interface do popup
├── popup.js           # Lógica do popup
├── background.js      # Service Worker (MV3)
├── content.js         # Content Script (extração Instagram)
└── README.md          # Este arquivo
```

## 🚀 Instalação

### 1. Modo Desenvolvedor (Load Unpacked)

1. Abra o Chrome e acesse `chrome://extensions/`
2. Ative o **Modo do desenvolvedor** (canto superior direito)
3. Clique em **Carregar sem compactação** (Load unpacked)
4. Selecione a pasta `xaigoo-extractor/`

### 2. Configuração do Backend

O backend deve estar rodando em `https://portal.xaigoo.app/api/save_lead.php` com:

- **Migration SQL executada** no banco `xaigoo_links-pipeline`:
  ```sql
  -- Arquivo: xaigoo-pipeline/database/migration_add_segmentation_level.sql
  ALTER TABLE `influencers` ADD COLUMN `segmentation_level` TINYINT NULL;
  ALTER TABLE `influencers` ADD UNIQUE KEY `uq_influencers_name_or_handle` (`name_or_handle`);
  ```

- **Chave DeepSeek configurada** em `xaigoo-pipeline/api/config.php`:
  ```php
  define('DEEPSEEK_API_KEY', 'sua_chave_aqui');
  ```

## 🔐 Autenticação

A extensão usa **compartilhamento de cookie de sessão**:

1. Faça login em `https://portal.xaigoo.app` com seu e-mail `@xaigoo.app` no navegador
2. A extensão lê o cookie `xaigoo_session` via `chrome.cookies.getAll()`
3. Envia o cookie manualmente no header `Cookie` das requisições POST

> **Importante:** O cookie deve ter `SameSite=Lax` ou `None; Secure` para funcionar cross-site. O backend já configura isso automaticamente.

## 🎯 Como Usar

1. **Abra a página de seguidores** de qualquer perfil Instagram:
   - Ex: `https://www.instagram.com/usuario/followers/`

2. **Abra a extensão** (ícone na barra do Chrome)
   - **Toggle Master**: Liga/Desliga a captura global
   - **Toggle IA**: Ativa qualificação via DeepSeek (Nível 1 = Forte aderência, Nível 2 = Neutro)
   - **Contador**: Mostra perfis enviados na sessão atual

3. **Role a página manualmente** (scroll)
   - A extensão detecta perfis visíveis no DOM automaticamente
   - Deduplica localmente (não reenvia o mesmo username na sessão)
   - Envia em lotes com throttle (300ms entre envios)

4. **Verifique no Pipeline** (`https://portal.xaigoo.app/pipeline`)
   - Leads aparecem com status "A pesquisar" e plataforma "Instagram"
   - Filtre por "Nível de Segmentação IA" na toolbar
   - Complete os campos restantes manualmente (audiência, justificativa, etc.)

## ⚙️ Funcionamento Técnico

### Content Script (`content.js`)

- **Ativação**: Só roda em URLs contendo `/followers/`
- **Extração**: `MutationObserver` + scan periódico (1.2s) para capturar scroll manual
- **Seletores**: Busca links `<a href="/username/">` em containers de seguidores
- **Filtros**: Ignora posts (`/p/`), reels, explore, direct, etc.
- **Deduplicação**: `Set` local de usernames já vistos na sessão
- **Envio**: `fetch` POST com cookie `xaigoo_session` no header
- **Retry**: Até 3 tentativas em caso de falha de rede

### Backend (`save_lead.php`)

- **Auth**: Exige sessão `@xaigoo.app` válida (`$_SESSION['user_id']`)
- **IA**: Se `ai_enabled=true`, chama DeepSeek V4 Flash (`deepseek-chat`)
- **Prompt**: Classifica username no nicho "motoristas de app / mobilidade"
- **Fallback IA**: Se falhar, salva com `segmentation_level = NULL` (não bloqueia)
- **Deduplicação BD**: `INSERT IGNORE` respeita UNIQUE em `name_or_handle`
- **Resposta**: `{ success, id, duplicate, segmentation_level, ai_used }`

### Pipeline (`PipelinePage.tsx`)

- **Filtro IA**: Dropdown "Todos níveis IA | Nível 1 | Nível 2 | Sem classificação IA"
- **Badges**: Exibe "IA: 1" (verde) ou "IA: 2" (âmbar) nas fichas/tabela/Kanban
- **Campos vazios**: Leads da extensão chegam com audience_type, justification, etc. vazios

## 🔧 Troubleshooting

### Extensão não captura perfis
- Verifique se está em página `/followers/` (não `/following/`)
- Confirme se "Ligar Extensão" está ATIVO no popup
- Abra DevTools (F12) no console da página Instagram - procure logs `[Xaigoo Extractor]`
- Instagram muda DOM frequentemente - seletores em `content.js` podem precisar ajuste

### Erro 401 / "Sem sessão válida"
- Faça login em `https://portal.xaigoo.app` no mesmo navegador
- Verifique se o cookie `xaigoo_session` existe: DevTools > Application > Cookies
- O domínio do cookie deve ser `portal.xaigoo.app` (ou subdomínio configurado)

### IA não classifica (sempre NULL)
- Verifique se `DEEPSEEK_API_KEY` está configurada em `api/config.php`
- Teste a chave: `curl -H "Authorization: Bearer SUA_KEY" https://api.deepseek.com/v1/models`
- Logs do PHP: `error_log` mostra erros da API DeepSeek

### Duplicados não são evitados
- Execute a migration SQL para criar UNIQUE em `name_or_handle`
- Verifique se há dados duplicados existentes antes de aplicar o UNIQUE

## 📝 Logs e Debug

- **Console da página Instagram** (F12): Logs de detecção, envio, erros
- **Console do popup** (clique direito no ícone > Inspecionar popup): Estado dos toggles, contador
- **Logs PHP** (servidor): `error_log` mostra chamadas DeepSeek e erros de BD

## 📄 Licença

Uso interno - Xaigoo